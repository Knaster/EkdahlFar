var searchData=
[
  ['validatenumber_734',['validateNumber',['../commandparser_8h.html#a310fc39293be4a49f11c7a377f37038f',1,'commandparser.h']]],
  ['value_735',['value',['../classaverager.html#ade0cac017e395f4b8a524d44b0d831ec',1,'averager']]],
  ['valueperrotation_736',['valuePerRotation',['../servostepper_8h.html#afede2097a25e7d6451771f11e431a6e1',1,'servostepper.h']]],
  ['velocity_737',['velocity',['../structnoteMsg.html#ab465b72dedecef1146ca0c584ef5c48f',1,'noteMsg']]],
  ['version_5fmajor_738',['VERSION_MAJOR',['../automaticversion_8hpp.html#a1a53b724b6de666faa8a9e0d06d1055f',1,'automaticversion.hpp']]],
  ['version_5fmajor_5finit_739',['VERSION_MAJOR_INIT',['../automaticversion_8hpp.html#a9a6e4b16934b64a76320ab8311ee89e5',1,'automaticversion.hpp']]],
  ['version_5fminor_740',['VERSION_MINOR',['../automaticversion_8hpp.html#ae0cb52afb79b185b1bf82c7e235f682b',1,'automaticversion.hpp']]],
  ['version_5fminor_5finit_741',['VERSION_MINOR_INIT',['../automaticversion_8hpp.html#ae7b1bf4e4cd95c0bcf4eec71a7ed1f0d',1,'automaticversion.hpp']]]
];
