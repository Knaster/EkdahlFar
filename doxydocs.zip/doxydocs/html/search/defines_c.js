var searchData=
[
  ['uservariablemax_1508',['userVariableMax',['../midi_8cpp.html#ac95cb2b2f0097507ba0b2e1666593a4a',1,'midi.cpp']]]
];
