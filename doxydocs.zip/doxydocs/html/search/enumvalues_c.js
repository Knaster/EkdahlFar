var searchData=
[
  ['textinfo_1420',['TextInfo',['../debugprint_8h.html#a7f327d12d94173c3c786ded0b10d2be4a701ce2c0c0eef34bc6aeaa5be3ae0d9c',1,'debugprint.h']]]
];
