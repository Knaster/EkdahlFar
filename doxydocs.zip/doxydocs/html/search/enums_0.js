var searchData=
[
  ['_5fspeedmode_1384',['_speedMode',['../bowcontrol_8h.html#a08216a942f96ea84df79ef77a0554dd8',1,'bowcontrol.h']]],
  ['_5ftiltmode_1385',['_tiltMode',['../bowcontrol_8h.html#a48bbfa20eaad6b3ba296a4fcb2857e0c',1,'bowcontrol.h']]]
];
