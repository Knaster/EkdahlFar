var searchData=
[
  ['value_1382',['value',['../classaverager.html#ade0cac017e395f4b8a524d44b0d831ec',1,'averager']]],
  ['velocity_1383',['velocity',['../structnoteMsg.html#ab465b72dedecef1146ca0c584ef5c48f',1,'noteMsg']]]
];
