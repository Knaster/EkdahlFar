var searchData=
[
  ['averager_751',['averager',['../classaverager.html',1,'']]]
];
