var searchData=
[
  ['addbow_805',['addBow',['../classstringModule.html#a52a5b213e054d030023de05b46769555',1,'stringModule']]],
  ['addbowactuator_806',['addBowActuator',['../classBowActuators.html#a98f6a860981a16e1af23b6356adff117',1,'BowActuators']]],
  ['addcommandhelp_807',['addCommandHelp',['../commandparser_8h.html#a55f22cf254c21b7922ea450b24b48dd2',1,'commandparser.h']]],
  ['addcommands_808',['addCommands',['../classcommandList.html#a904e6e8220f9141ed807005326dd96f6',1,'commandList']]],
  ['adddata_809',['addData',['../classaverager.html#aaa54da4b2f567beab8279a63a683a4bb',1,'averager']]],
  ['addharmonicseries_810',['addHarmonicSeries',['../classHarmonicSeriesList.html#a7c71abff4db71f6d336b524770535800',1,'HarmonicSeriesList::addHarmonicSeries()'],['../classHarmonicSeriesList.html#a34084fec0dce96af5366b080c8b98f8d',1,'HarmonicSeriesList::addHarmonicSeries(float frequency[])']]],
  ['addmute_811',['addMute',['../classstringModule.html#ae900a34fa51bb9cdf8e0db8ad54698ee',1,'stringModule']]],
  ['addnote_812',['addNote',['../midi_8cpp.html#adae513bd93c17269a7aa93788cb85a8d',1,'midi.cpp']]],
  ['addsolenoid_813',['addSolenoid',['../classstringModule.html#a383d333da12d8b196c3a0a3085f466c9',1,'stringModule']]],
  ['addtachofreq_814',['addTachoFreq',['../classbowIO.html#ab0bb402f5ebc7607c4e3f473f58e914a',1,'bowIO']]],
  ['addtestdata_815',['addTestData',['../classcontrolReader.html#a82cd99250ee474229be705d1c48b277f',1,'controlReader']]],
  ['audiofrequency_816',['audioFrequency',['../audioanalyze_8h.html#a8ecd861231dbd0db5f6e4771b3422137',1,'audioanalyze.h']]],
  ['audiofrequencyavaliable_817',['audioFrequencyAvaliable',['../audioanalyze_8h.html#aa486c0bb291c2cef78ca63c3169f303b',1,'audioanalyze.h']]],
  ['audiopeakamplitude_818',['audioPeakAmplitude',['../audioanalyze_8h.html#a46623e59a36a0f978fef31fb33f2efd1',1,'audioanalyze.h']]],
  ['audioprocessorusage_819',['audioProcessorUsage',['../audioanalyze_8h.html#a1119501c55b77d995f19fb79432bfe53',1,'audioanalyze.h']]],
  ['audiormsamplitude_820',['audioRMSAmplitude',['../audioanalyze_8h.html#ae3b3ce9622c1f8f5f25f46ebe4bc8ced',1,'audioanalyze.h']]],
  ['averagefreq_821',['averageFreq',['../classbowIO.html#a4f7ef490b19cc4d9d6e3bd2e65d77061',1,'bowIO']]],
  ['averager_822',['averager',['../classaverager.html#a984c8c03a83d4d02ed1cfeb1f5f320ae',1,'averager']]]
];
