var searchData=
[
  ['notemsg_767',['noteMsg',['../structnoteMsg.html',1,'']]]
];
